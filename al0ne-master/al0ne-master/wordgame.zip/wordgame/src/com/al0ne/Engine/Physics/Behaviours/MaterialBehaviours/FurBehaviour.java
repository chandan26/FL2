package com.al0ne.Engine.Physics.Behaviours.MaterialBehaviours;

import com.al0ne.Engine.Physics.Behaviour;

/**
 * Created by BMW on 20/07/2017.
 */
public class FurBehaviour extends Behaviour {
    public FurBehaviour(String s) {
        super(s);
    }
}
