﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCAPP.Models;

namespace MVCAPP.Controllers
{
    public class conferenceController : Controller
    {
        // GET: conference
        public ActionResult Index()
        {
            using (MVCDBEntities mvcdb = new MVCDBEntities())
            {
                return View(mvcdb.conferences.ToList());
            }
            
        }

        // GET: conference/Details/5
        public ActionResult Details(int? id)
        {
            using (MVCDBEntities adb = new MVCDBEntities())
            {
                return View(adb.conferences.Where(x => x.conferenceid == id).FirstOrDefault());
            }
        }

        // GET: conference/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: conference/Create
        [HttpPost]
        public ActionResult Create(conference confer)
        {
            try
            {
                using(MVCDBEntities mvcd= new MVCDBEntities())
                {
                    mvcd.conferences.Add(confer);
                    mvcd.SaveChanges();

                }
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: conference/Edit/5
        public ActionResult Edit(int? id)
        {
            using (MVCDBEntities adb = new MVCDBEntities())
            {
                return View(adb.conferences.Where(x => x.conferenceid == id).FirstOrDefault());
            }
        }

        // POST: conference/Edit/5
        [HttpPost]
        public ActionResult Edit(int? id, conference confer)
        {
            try
            {
                using (MVCDBEntities dbc = new MVCDBEntities())
                {
                    dbc.Entry(confer).State = EntityState.Modified;
                    dbc.SaveChanges();
                }
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: conference/Delete/5
        public ActionResult Delete(int? id)
        {
            using (MVCDBEntities dbc= new MVCDBEntities())
            {
                return View(dbc.conferences.Where(x => x.conferenceid == id).FirstOrDefault());
            }
        }

        // POST: conference/Delete/5
        [HttpPost]
        public ActionResult Delete(int? id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                using (MVCDBEntities adbins = new MVCDBEntities())
                {
                   conference confdb = adbins.conferences.Where(x => x.conferenceid == id).FirstOrDefault();
                    adbins.conferences.Remove(confdb);
                    adbins.SaveChanges();
                }
                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
