# Social Network for College

A Social Network for college students where the students can share their details and interests.  
The students can post their thoughts and views about anything and the same will be visible to all other students on their timeline.  
Also, the students can search for other students by their class or by their interests.

# Developers
* Jimit Dholakia
* Isaac Maria
