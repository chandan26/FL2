﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCAPP.Models;

namespace MVCAPP.Controllers
{
    public class papersController : Controller
    {
        // GET: papers
        public ActionResult Index()
        {
            using (MVCDBEntities mvcdb = new MVCDBEntities())
            {
                return View(mvcdb.papers.ToList());
            }
        }

        // GET: papers/Details/5
        public ActionResult Details(int? id)
        {
            using (MVCDBEntities adb = new MVCDBEntities())
            {
                return View(adb.papers.Where(x => x.paperid == id).FirstOrDefault());
            }
        }

        // GET: papers/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: papers/Create
        [HttpPost]
        public ActionResult Create(paper pconf)
        {
            try
            {

                using (MVCDBEntities mvcd = new MVCDBEntities())
                {
                    mvcd.papers.Add(pconf);
                    mvcd.SaveChanges();

                }
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: papers/Edit/5
        public ActionResult Edit(int? id)
        {
            using(MVCDBEntities adb = new MVCDBEntities())
            {
                return View(adb.papers.Where(x => x.paperid == id).FirstOrDefault());
            }
        }

        // POST: papers/Edit/5
        [HttpPost]
        public ActionResult Edit(int? id, paper atn)
        {
            try
            {

                using (MVCDBEntities dbc = new MVCDBEntities())
                {
                    dbc.Entry(atn).State = EntityState.Modified;
                    dbc.SaveChanges();
                }
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: papers/Delete/5
        public ActionResult Delete(int? id)
        {
            using (MVCDBEntities dbc = new MVCDBEntities())
            {
                return View(dbc.papers.Where(x => x.paperid == id).FirstOrDefault());
            }
        }

        // POST: papers/Delete/5
        [HttpPost]
        public ActionResult Delete(int? id, FormCollection collection)
        {
            try
            {
                using (MVCDBEntities adbins = new MVCDBEntities())
                {

                    paper confdb = adbins.papers.Where(x => x.paperid == id).FirstOrDefault();
                    adbins.papers.Remove(confdb);
                    adbins.SaveChanges();
                }



                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
