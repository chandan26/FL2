package com.al0ne.Engine.Physics.Behaviours.MaterialBehaviours;

import com.al0ne.Engine.Physics.Behaviour;

import static com.al0ne.Engine.Main.printToLog;

/**
 * Created by BMW on 09/07/2017.
 */
public class IronBehaviour extends Behaviour {

    public IronBehaviour() {
        super("iron");
    }
}
