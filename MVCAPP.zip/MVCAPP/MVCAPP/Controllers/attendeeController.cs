﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCAPP.Models;


namespace MVCAPP.Controllers
{
    public class attendeeController : Controller
    {
        // GET: attendee
        public ActionResult Index()
        {
            using (MVCDBEntities mvcdb = new MVCDBEntities())
            {
                return View(mvcdb.attendees.ToList());
            }
        }

        // GET: attendee/Details/5
        public ActionResult Details(int? id)
        {
            using (MVCDBEntities adb = new MVCDBEntities())
            {
                return View(adb.attendees.Where(x => x.attendeeid == id).FirstOrDefault());
            }
        }

        // GET: attendee/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: attendee/Create
        [HttpPost]
        public ActionResult Create(attendee conf)
        {
            try
            {
                using (MVCDBEntities mvcd = new MVCDBEntities())
                {
                    mvcd.attendees.Add(conf);
                    mvcd.SaveChanges();

                }
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: attendee/Edit/5
        public ActionResult Edit(int? id)
        {
            using (MVCDBEntities adb = new MVCDBEntities())
            {
                return View(adb.attendees.Where(x => x.attendeeid == id).FirstOrDefault());
            }
        }

        // POST: attendee/Edit/5
        [HttpPost]
        public ActionResult Edit(int? id, attendee atn)
        {
            try
            {
                using (MVCDBEntities dbc = new MVCDBEntities())
                {
                    dbc.Entry(atn).State = EntityState.Modified;
                    dbc.SaveChanges();
                }
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: attendee/Delete/5
        public ActionResult Delete(int? id)
        {
            using (MVCDBEntities dbc = new MVCDBEntities())
            {
                return View(dbc.attendees.Where(x => x.attendeeid == id).FirstOrDefault());
            }
        }

        // POST: attendee/Delete/5
        [HttpPost]
        public ActionResult Delete(int? id, FormCollection collection)
        {
            try
            {
                using (MVCDBEntities adbins = new MVCDBEntities())
                {
                    
                    attendee confdb = adbins.attendees.Where(x => x.attendeeid == id).FirstOrDefault();
                    adbins.attendees.Remove(confdb);
                    adbins.SaveChanges();
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
