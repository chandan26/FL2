package com.al0ne.Engine.Physics.Behaviours;

import com.al0ne.Engine.Physics.Behaviour;

public class BatteryBehaviour extends Behaviour {
    public BatteryBehaviour(String s) {
        super(s);
    }
}
