package com.al0ne.ConcreteEntities.NPCs;

import java.io.Serializable;

public abstract class Generator implements Serializable{
}
