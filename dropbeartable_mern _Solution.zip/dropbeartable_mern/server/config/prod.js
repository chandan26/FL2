module.exports = {
    DB_URI: '**',
    SECRET: '**'
}
