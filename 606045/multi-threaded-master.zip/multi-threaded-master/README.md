# Project README #


### What is this repository for? ###

This JavaFX application was an assignment for my Advanced Java Class. 
This a multi-threaded application in which a user can add balls to the JavaFX window. Balls bounce off of walls, and each other. 

### Attribution Notice ###

For the ProThreaded project, I have used code from the following sources, which are referenced throughout the .java files. 

**sources**:
* http://stackoverflow.com/questions/1250643/how-to-wait-for-all-threads-to-finish-using-executorservice
* http://hyperphysics.phy-astr.gsu.edu/hbase/colsta.html
* https://gist.github.com/james-d/8327842
* proThreaded base code
