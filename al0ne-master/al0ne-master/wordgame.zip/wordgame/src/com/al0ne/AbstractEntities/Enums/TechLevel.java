package com.al0ne.AbstractEntities.Enums;

public enum TechLevel {
    BASE,
    LOW,
    MEDIUM,
    HIGH
}
