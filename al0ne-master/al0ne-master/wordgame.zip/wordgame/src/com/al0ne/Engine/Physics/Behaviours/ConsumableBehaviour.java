package com.al0ne.Engine.Physics.Behaviours;

import com.al0ne.Engine.Physics.Behaviour;

public class ConsumableBehaviour extends Behaviour {
    public ConsumableBehaviour() {
        super("consumable");
    }
}
